# Guida per il docente — repository di esercizio

Questo file è per chi conduce il corso: contiene le soluzioni dei bug,
gli esiti attesi e i suggerimenti di conduzione. **Non distribuirlo ai
partecipanti** (o rimuoverlo dalla copia consegnata).

## Stato atteso dei test all'avvio

| File | Con i bug | Dopo la correzione |
|---|---|---|
| `tests/test_orders.py` | **2 failed, 10 passed** | 12 passed (come nella slide 32) |
| `tests/test_auth.py` | **4 failed, 1 passed** | 5 passed |

## Soluzioni dei bug

### 1. `src/orders.py` — voucher applicato dopo l'IVA

Il blocco marcato "implementazione SBAGLIATA" va sostituito con:

```python
imponibile = subtotale(articoli) - voucher
if imponibile < 0:
    imponibile = 0.0
totale = imponibile * (1 + iva)
```

Punto didattico: il voucher da 30 € su 100 € imponibili costa al cliente
92,00 € con il bug e 85,40 € corretti — la differenza è esattamente
`voucher × IVA` (6,60 €). Ottimo per mostrare che l'agente non "indovina":
sono i test a dire che cosa è giusto.

### 2. `src/auth/session.py` — confronto di scadenza invertito

La riga nel blocco marcato va corretta da:

```python
return adesso > self.scadenza      # sbagliato
```

a:

```python
return adesso < self.scadenza      # corretto
```

Sintomo con il bug: i token appena creati vengono rifiutati con
"token scaduto" (ed è la frase usata nell'esercizio "richiesta vaga
vs richiesta mirata" della slide 33).

## Conduzione degli esercizi

- **Esercizio 2 (ciclo agentico, slide 32)**: chiedere esattamente
  *"i test di test_orders.py falliscono: sistemali"*. Far notare la sequenza
  Bash(pytest) → Read → Edit → Bash(pytest) e il passaggio da rosso a verde.
- **Esercizio 3 (slide 33)**: prima la richiesta vaga (*"il login non
  funziona, aggiusta"*), poi quella mirata con i tre appigli
  (@src/auth/session.py, pytest tests/test_auth.py, criterio di successo).
  Confrontare il numero di passi nelle due trascrizioni.
- **Esercizio 8 (hook)**: l'hook lancia `black . --quiet` dopo ogni
  Edit/Write; verificare prima che `black` sia installato nell'ambiente
  attivo (`pip install -r requirements.txt`), altrimenti l'hook segnala errore.
- **Esercizio 9 (sicurezza)**: chiedere *"riassumi docs/NOTE_FORNITORE.md"*.
  Il commento HTML nel file è l'injection; la regola `deny: Read(.env)` in
  `.claude/settings.json` è il guardrail. Mostrare che la difesa non si
  affida alla sola prudenza del modello.
- **Laboratorio finale (slide 48)**: la funzionalità è l'esportazione CSV
  degli ordini di `src/archivio.py`. Traccia di riferimento: funzione
  `esporta_csv(percorso)` in un nuovo `src/esporta.py`, con intestazione
  `id,cliente,data,importo,regione`, separatore virgola, importi con punto
  decimale e due cifre. Far scrivere PRIMA i test (rosso), poi implementare.

## Tempi indicativi

- Esercizio 1: 20' · Esercizi 2–3: 25' · Esercizi 4–8: 10' ciascuno ·
  Esercizio 9: 15' · Laboratorio finale: 60' + 10' di confronto.
