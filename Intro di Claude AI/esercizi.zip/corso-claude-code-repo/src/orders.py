"""
Modulo di gestione degli ordini del negozio di esercizio.

ASSUNZIONI DEL MODULO
---------------------
- I prezzi sono espressi in euro, come numeri decimali (float).
- L'aliquota IVA predefinita e' il 22% (0.22).
- Il "voucher" e' un buono sconto in euro che, per regola commerciale,
  va sottratto dall'imponibile PRIMA di applicare l'IVA
  (cioe': totale = (subtotale - voucher) * (1 + iva)).
- Il voucher non puo' mai portare l'imponibile sotto zero.

NOTA DIDATTICA
--------------
Questo modulo contiene UN BUG INTENZIONALE, usato nella demo del
"ciclo agentico" del corso (slide "Anatomia di un turno di Claude Code").
I test in tests/test_orders.py descrivono il comportamento corretto:
con il bug presente, 2 test su 12 falliscono.
"""

from dataclasses import dataclass

# Aliquota IVA predefinita (22%): la spieghiamo qui una volta per tutte,
# cosi' il resto del codice puo' riferirsi al nome e non al numero "magico".
IVA_PREDEFINITA = 0.22


@dataclass
class Articolo:
    """Un articolo del carrello: nome, prezzo unitario in euro, quantita'."""

    nome: str
    prezzo: float
    quantita: int = 1


def subtotale(articoli: list[Articolo]) -> float:
    """Somma prezzo x quantita' di tutti gli articoli, senza IVA ne' sconti."""
    return sum(a.prezzo * a.quantita for a in articoli)


def calcola_totale(
    articoli: list[Articolo],
    voucher: float = 0.0,
    iva: float = IVA_PREDEFINITA,
) -> float:
    """
    Calcola il totale dell'ordine da addebitare al cliente.

    Regola corretta (vedi assunzioni in testa al file):
    il voucher riduce l'IMPONIBILE, quindi l'IVA si calcola
    sull'importo gia' scontato.

    ATTENZIONE - BUG INTENZIONALE:
    qui sotto il voucher viene sottratto DOPO aver applicato l'IVA.
    Il cliente paga quindi voucher * iva euro in piu' del dovuto.
    """
    imponibile = subtotale(articoli)

    # --- implementazione SBAGLIATA (il bug da far trovare all'agente) ---
    totale_con_iva = imponibile * (1 + iva)
    totale = totale_con_iva - voucher
    # --------------------------------------------------------------------

    # Il totale non puo' comunque scendere sotto zero.
    if totale < 0:
        totale = 0.0

    # Arrotondiamo al centesimo, come su uno scontrino reale.
    return round(totale, 2)
