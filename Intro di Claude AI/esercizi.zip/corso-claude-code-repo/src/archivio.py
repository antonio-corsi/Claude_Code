"""
Archivio degli ordini di esempio.

Serve da sorgente dati per l'esercizio di pianificazione del corso
("Aggiungi l'esportazione CSV degli ordini"): l'esportatore CSV
NON esiste ancora ed e' proprio il compito da svolgere con Claude Code
in Plan mode e poi nel laboratorio finale (TDD).

Ogni ordine e' un dizionario con chiavi:
- id        : identificativo numerico dell'ordine
- cliente   : nome del cliente
- data      : data dell'ordine in formato ISO (AAAA-MM-GG)
- importo   : totale in euro gia' comprensivo di IVA
- regione   : regione di spedizione
"""

ORDINI = [
    {"id": 1001, "cliente": "Rossi Srl", "data": "2026-10-01", "importo": 244.00, "regione": "Piemonte"},
    {"id": 1002, "cliente": "Bianchi Spa", "data": "2026-10-02", "importo": 1830.50, "regione": "Lombardia"},
    {"id": 1003, "cliente": "Verdi Snc", "data": "2026-10-02", "importo": 97.60, "regione": "Veneto"},
    {"id": 1004, "cliente": "Rossi Srl", "data": "2026-10-05", "importo": 512.40, "regione": "Piemonte"},
    {"id": 1005, "cliente": "Neri & C.", "data": "2026-10-07", "importo": 61.00, "regione": "Lazio"},
    {"id": 1006, "cliente": "Bianchi Spa", "data": "2026-10-09", "importo": 2440.00, "regione": "Lombardia"},
]


def elenco_ordini() -> list[dict]:
    """Restituisce l'elenco completo degli ordini (copia superficiale)."""
    return list(ORDINI)
