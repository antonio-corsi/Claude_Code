# Pacchetto "auth": gestione delle sessioni di accesso dell'applicazione di esercizio.
