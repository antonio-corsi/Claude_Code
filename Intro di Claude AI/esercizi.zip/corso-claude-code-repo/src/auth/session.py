"""
Gestione delle sessioni di accesso (login) dell'applicazione di esercizio.

ASSUNZIONI DEL MODULO
---------------------
- Un "token" e' una stringa che identifica una sessione aperta.
- Ogni sessione ha una scadenza (oggetto datetime): dopo quell'istante
  il token NON e' piu' valido e il login va rifiutato.
- Regola corretta: una sessione e' valida se l'istante attuale
  e' PRECEDENTE alla scadenza (adesso < scadenza).

NOTA DIDATTICA
--------------
Questo modulo contiene UN BUG INTENZIONALE, usato nell'esercizio
"richiesta vaga vs richiesta mirata" del corso: il confronto di
scadenza e' invertito, quindi i token appena creati vengono rifiutati
con l'errore "token scaduto" e, al contrario, i token scaduti
vengono accettati. I test in tests/test_auth.py descrivono il
comportamento corretto: con il bug presente, falliscono.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta

# Durata predefinita di una sessione: 30 minuti.
DURATA_SESSIONE = timedelta(minutes=30)


@dataclass
class Sessione:
    """Una sessione di accesso: token e istante di scadenza."""

    token: str
    scadenza: datetime

    def e_valida(self, adesso: datetime | None = None) -> bool:
        """
        Dice se la sessione e' ancora valida all'istante indicato
        (se non indicato, usa l'istante attuale).

        ATTENZIONE - BUG INTENZIONALE: il confronto e' invertito.
        La versione corretta sarebbe:  return adesso < self.scadenza
        """
        if adesso is None:
            adesso = datetime.now()
        # --- implementazione SBAGLIATA (il bug da far trovare all'agente) ---
        return adesso > self.scadenza
        # --------------------------------------------------------------------


def apri_sessione(utente: str, adesso: datetime | None = None) -> Sessione:
    """
    Apre una nuova sessione per l'utente indicato e restituisce
    la Sessione con token e scadenza impostata a DURATA_SESSIONE da adesso.
    """
    if adesso is None:
        adesso = datetime.now()
    token = f"tok-{utente}-{adesso.timestamp():.0f}"
    return Sessione(token=token, scadenza=adesso + DURATA_SESSIONE)


def verifica_login(sessione: Sessione, adesso: datetime | None = None) -> str:
    """
    Verifica una sessione al momento del login.

    Restituisce "ok" se la sessione e' valida, altrimenti solleva
    un errore con il messaggio "token scaduto" (il sintomo che
    l'utente vede nell'esercizio del corso).
    """
    if sessione.e_valida(adesso):
        return "ok"
    raise PermissionError("token scaduto")
