# Pacchetto "src" del progetto di esercizio del corso "AI agentica con Claude Code".
# Non contiene codice: serve solo a rendere importabile la cartella come pacchetto Python.
