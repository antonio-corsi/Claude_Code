Spiega il modulo $ARGUMENTS a un collega appena arrivato nel progetto.

Struttura la spiegazione così, in italiano:

1. **Scopo**: a che cosa serve il modulo, in due frasi.
2. **Funzioni principali**: una riga per ciascuna funzione o classe pubblica.
3. **Dipendenze**: da quali altri moduli dipende e chi lo usa.
4. **Punti delicati**: assunzioni, casi limite, zone del codice da toccare con cautela.

Spiega ogni termine tecnico la prima volta che compare e non dare nulla per scontato.
