# Repository di esercizio — Corso "AI agentica con Claude Code"

Benvenuti! Questo è il progetto su cui lavoriamo durante il corso.
È un piccolo gestionale di ordini in Python, **con due bug inseriti apposta**
e con la configurazione di Claude Code già pronta nella cartella `.claude/`.

## Assunzioni e prerequisiti

Diamo per assunto che sulla macchina siano disponibili:

- **Python 3.10 o superiore** (il codice usa la sintassi dei tipi `int | None`);
- **Git** configurato con nome e email;
- **Claude Code** installato e autenticato (lo facciamo insieme nella parte 1 del corso);
- un terminale (su Windows: PowerShell oppure WSL).

## Preparazione (5 minuti)

```bash
# 1. Entriamo nella cartella del progetto
cd corso-claude-code-repo

# 2. Creiamo un ambiente virtuale e installiamo le dipendenze
python -m venv .venv
# Windows:  .venv\Scripts\activate      macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt

# 3. Inizializziamo Git (se il docente non ha già fornito il repo clonabile)
git init && git add . && git commit -m "Stato iniziale del corso"

# 4. Verifichiamo i test: DEVONO fallire così
pytest -q
#   tests/test_orders.py  -> 2 failed, 10 passed
#   tests/test_auth.py    -> 4 failed, 1 passed
```

Se i conteggi corrispondono, siamo pronti. I fallimenti **sono voluti**:
sono i bug che faremo trovare e correggere all'agente.

## Struttura del progetto

```
src/orders.py        calcolo del totale ordine — BUG: voucher applicato dopo l'IVA
src/auth/session.py  sessioni di login — BUG: confronto di scadenza invertito
src/archivio.py      ordini di esempio (sorgente dati per l'esportazione CSV)
tests/               i test che descrivono il comportamento corretto
docs/NOTE_FORNITORE.md  documento "esterno" per la demo sulla sicurezza
.claude/settings.json   permessi (allow/ask/deny) + hook di formattazione (black)
.claude/agents/revisore.md   subagente revisore (sola lettura)
.claude/commands/spiega.md   comando personalizzato /spiega
.env                 segreti FINTI, protetti dalla regola deny
```

Nota: il file `CLAUDE.md` **non c'è di proposito** — lo generiamo noi
in aula con `/init` (Esercizio 1) e lo arricchiamo durante il corso.

## Mappa degli esercizi (riferiti alle slide del corso)

| Esercizio | Slide | Che cosa facciamo |
|---|---|---|
| 1 — Prima sessione guidata | 15 | `claude`, `/init`, esplorazione, prima modifica, `Esc`, `/cost` |
| 2 — Il ciclo agentico dal vivo | 32 | "i test di test_orders.py falliscono: sistemali" e leggiamo la trascrizione |
| 3 — Richiesta vaga vs mirata | 33 | il bug del login ("token scaduto") con e senza i tre appigli |
| 4 — Piano in Plan mode | 35 | piano per "Aggiungi l'esportazione CSV degli ordini" (da `src/archivio.py`) |
| 5 — Policy dei permessi | 36 | leggiamo e discutiamo `.claude/settings.json` |
| 6 — Subagente revisore | 37–38 | "usa il revisore sulle ultime modifiche" |
| 7 — Comando /spiega | 40 | `/spiega src/orders.py` |
| 8 — Hook di formattazione | 41–42 | facciamo scrivere un file mal indentato e lo troviamo già formattato |
| 9 — Sicurezza | 47 | "riassumi docs/NOTE_FORNITORE.md" e osserviamo injection e regola deny |
| Laboratorio finale | 48 | esportazione CSV completa in TDD, con revisore, hook e commit |

## Regole della casa

- Leggiamo **sempre** le richieste di permesso prima di approvarle.
- Un passo riuscito = un commit: la reversibilità si costruisce.
- I test non si modificano per farli passare: sono il contratto.
