"""
Test del modulo ordini (src/orders.py).

Questi test descrivono il COMPORTAMENTO CORRETTO del calcolo del totale:
il voucher (buono sconto in euro) riduce l'imponibile PRIMA dell'IVA.

Con il bug intenzionale presente nel modulo, l'esecuzione attesa e':
    2 failed, 10 passed
Dopo la correzione fatta con Claude Code:
    12 passed
"""

import pytest

from src.orders import Articolo, calcola_totale, subtotale


# ---------------------------------------------------------------------------
# Subtotale: la somma semplice, senza IVA ne' sconti
# ---------------------------------------------------------------------------

def test_subtotale_carrello_vuoto():
    # Un carrello vuoto vale zero.
    assert subtotale([]) == 0


def test_subtotale_articolo_singolo():
    # Un solo articolo: il subtotale e' il suo prezzo.
    assert subtotale([Articolo("penna", 2.50)]) == 2.50


def test_subtotale_con_quantita():
    # Il prezzo va moltiplicato per la quantita'.
    assert subtotale([Articolo("quaderno", 3.00, quantita=4)]) == 12.00


# ---------------------------------------------------------------------------
# Totale senza voucher: solo IVA
# ---------------------------------------------------------------------------

def test_totale_carrello_vuoto():
    assert calcola_totale([]) == 0.0


def test_totale_senza_voucher_con_iva_predefinita():
    # 100 euro di imponibile + IVA 22% = 122 euro.
    carrello = [Articolo("zaino", 100.00)]
    assert calcola_totale(carrello) == 122.00


def test_totale_senza_voucher_iva_zero():
    # Con IVA a zero il totale coincide con il subtotale.
    carrello = [Articolo("zaino", 100.00)]
    assert calcola_totale(carrello, iva=0.0) == 100.00


def test_totale_quantita_multiple():
    # 3 x 10 euro + 1 x 20 euro = 50 euro; con IVA 22% = 61 euro.
    carrello = [Articolo("maglietta", 10.00, 3), Articolo("cappello", 20.00)]
    assert calcola_totale(carrello) == 61.00


def test_arrotondamento_al_centesimo():
    # 19.99 * 1.22 = 24.3878 -> sullo scontrino: 24.39 euro.
    carrello = [Articolo("libro", 19.99)]
    assert calcola_totale(carrello) == 24.39


# ---------------------------------------------------------------------------
# Voucher: il buono sconto riduce l'imponibile PRIMA dell'IVA
# ---------------------------------------------------------------------------

def test_voucher_con_iva_zero():
    # Senza IVA l'ordine delle operazioni non cambia il risultato:
    # 100 - 30 = 70 euro.
    carrello = [Articolo("zaino", 100.00)]
    assert calcola_totale(carrello, voucher=30.00, iva=0.0) == 70.00


def test_voucher_maggiore_del_subtotale():
    # Il totale non puo' mai scendere sotto zero.
    carrello = [Articolo("penna", 100.00)]
    assert calcola_totale(carrello, voucher=150.00, iva=0.0) == 0.0


def test_voucher_riduce_l_imponibile_prima_dell_iva():
    # QUESTO E' IL CASO CHE SMASCHERA IL BUG.
    # Corretto: (100 - 30) * 1.22 = 85.40 euro.
    # Sbagliato (bug): 100 * 1.22 - 30 = 92.00 euro.
    carrello = [Articolo("zaino", 100.00)]
    assert calcola_totale(carrello, voucher=30.00) == 85.40


def test_voucher_su_carrello_multiplo_con_iva():
    # Subtotale 200 euro, voucher 50:
    # corretto: (200 - 50) * 1.22 = 183.00 euro.
    carrello = [Articolo("giacca", 150.00), Articolo("cintura", 50.00)]
    assert calcola_totale(carrello, voucher=50.00) == pytest.approx(183.00)
