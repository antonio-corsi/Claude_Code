"""
Test del modulo sessioni (src/auth/session.py).

Questi test descrivono il COMPORTAMENTO CORRETTO:
una sessione e' valida se l'istante attuale precede la scadenza.

Con il bug intenzionale presente (confronto invertito), l'esecuzione attesa e':
    4 failed, 1 passed
Dopo la correzione fatta con Claude Code:
    5 passed
"""

from datetime import datetime, timedelta

import pytest

from src.auth.session import DURATA_SESSIONE, apri_sessione, verifica_login

# Un istante fisso di riferimento, per rendere i test deterministici
# (cioe' ripetibili: non dipendono dall'orologio del computer).
ADESSO = datetime(2026, 10, 13, 9, 0, 0)


def test_apertura_sessione_imposta_token_e_scadenza():
    # La sessione appena aperta ha un token non vuoto
    # e scade esattamente dopo DURATA_SESSIONE.
    sessione = apri_sessione("antonio", adesso=ADESSO)
    assert sessione.token != ""
    assert sessione.scadenza == ADESSO + DURATA_SESSIONE


def test_sessione_appena_aperta_e_valida():
    # Un token appena creato DEVE essere valido.
    sessione = apri_sessione("antonio", adesso=ADESSO)
    assert sessione.e_valida(adesso=ADESSO + timedelta(minutes=1))


def test_sessione_scaduta_non_e_valida():
    # Oltre la scadenza, il token NON e' piu' valido.
    sessione = apri_sessione("antonio", adesso=ADESSO)
    dopo_la_scadenza = ADESSO + DURATA_SESSIONE + timedelta(minutes=1)
    assert not sessione.e_valida(adesso=dopo_la_scadenza)


def test_login_accettato_con_sessione_valida():
    # Il login con una sessione valida restituisce "ok".
    sessione = apri_sessione("antonio", adesso=ADESSO)
    esito = verifica_login(sessione, adesso=ADESSO + timedelta(minutes=5))
    assert esito == "ok"


def test_login_rifiutato_con_token_scaduto():
    # Il login con un token scaduto solleva l'errore "token scaduto".
    sessione = apri_sessione("antonio", adesso=ADESSO)
    dopo_la_scadenza = ADESSO + DURATA_SESSIONE + timedelta(hours=1)
    with pytest.raises(PermissionError, match="token scaduto"):
        verifica_login(sessione, adesso=dopo_la_scadenza)
